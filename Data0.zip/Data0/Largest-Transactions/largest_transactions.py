import pandas as pd
import os
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor

CHUNK_SIZE = 100000
CPU_COUNT = os.cpu_count()
TOP_N_TRANSACTIONS = 10

def process_chunk(chunk):
    chunk['token_amount'] = chunk['data0'].apply(lambda x: int(x, 16)) / (10 ** 18)
    return chunk

if __name__ == '__main__':
    print("Starting the program...")

    df = pd.read_csv(r"C:\Users\Georgino\Desktop\FNCE-559-Project-2\group4.csv")

    chunks = (df[i:i+CHUNK_SIZE] for i in range(0, len(df), CHUNK_SIZE))

    processed_data = pd.DataFrame()

    with ProcessPoolExecutor(max_workers=CPU_COUNT) as executor:
        for chunk_number, processed_chunk in enumerate(executor.map(process_chunk, chunks)):
            processed_data = pd.concat([processed_data, processed_chunk])
            if chunk_number % 10 == 0:
                print(f"Processed {chunk_number * CHUNK_SIZE:,} rows...")

    largest_transactions = processed_data.sort_values(by='token_amount', ascending=False).head(TOP_N_TRANSACTIONS)

    largest_transactions.to_csv(r"C:\Users\Georgino\Desktop\FNCE-559-Project-2\largest_transactions.csv", index=False)

    for tx in largest_transactions['tx_hash']:
        if tx not in df['tx_hash'].values:
            print(f"Error: Transaction hash {tx} from the largest transactions is not found in the original dataset!")

    print("\nRows with the largest token amounts:")
    print(largest_transactions[['tx_hash', 'token_amount']])

    plt.figure(figsize=(12, 6))
    plt.barh(largest_transactions['tx_hash'], largest_transactions['token_amount'], color='blue')
    plt.title(f'Top {TOP_N_TRANSACTIONS} Largest Transactions')
    plt.ylabel('Transaction Hash')
    plt.xlabel('Token Amount')
    plt.tight_layout()

    filename = 'largest_transactions.png'
    plt.savefig(filename, dpi=300)
    plt.close()

    print("\nVisualizations saved!")
    print("\nLargest transactions saved to CSV!")
