import pandas as pd
import matplotlib.pyplot as plt

file_path = r"C:\Users\Georgino\Desktop\FNCE-559-Project-2\group4.csv"
df = pd.read_csv(file_path)

complexities = df.groupby('tx_hash').size()

complexity_counts = complexities.value_counts().sort_index()

plt.figure(figsize=(12, 6))
complexity_counts.plot(kind='bar', logy=True)
plt.title('Distribution of Transaction Complexities')
plt.xlabel('Complexity (Number of Logs)')
plt.ylabel('Number of Transactions (Log Scale)')
plt.tight_layout()
plt.savefig('complexity_distribution.png', dpi=300)

highest_complexity = complexities.max()
highest_complexity_txns = complexities[complexities == highest_complexity].index.tolist()

print(f"\nTransactions with the highest complexity ({highest_complexity} logs):")
for tx_hash in highest_complexity_txns:
    print(tx_hash)
