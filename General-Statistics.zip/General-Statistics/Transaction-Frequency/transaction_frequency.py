import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor
import os
from itertools import islice

CHUNK_SIZE = 100000
CPU_COUNT = os.cpu_count()

def process_chunk(chunk):
    daily_chunk = chunk.groupby(chunk['signed_at'].dt.day).size()
    monthly_chunk = chunk.groupby(chunk['signed_at'].dt.month).size()
    yearly_chunk = chunk.groupby(chunk['signed_at'].dt.year).size()
    return daily_chunk, monthly_chunk, yearly_chunk

def plot_and_save(data, title, filename, x_ticks, x_label):
    data.plot(kind='bar', figsize=(15,7))
    plt.title(title)
    plt.ylabel('Number of Transactions')
    plt.xlabel(x_label)
    plt.xticks(range(len(x_ticks)), x_ticks, rotation=45)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()

def split_dataframe(df, chunk_size): 
    num_chunks = len(df) // chunk_size + 1
    return (df[i*chunk_size:(i+1)*chunk_size] for i in range(num_chunks))

if __name__ == '__main__':
    df = pd.read_csv('C:\\Users\\Georgino\\Desktop\\FNCE-559-Project-2\\group4.csv', parse_dates=["signed_at"])

    df = df.drop_duplicates(subset='tx_hash', keep='first')

    chunks = split_dataframe(df, CHUNK_SIZE)

    daily_freq = {}
    monthly_freq = {}
    yearly_freq = {}

    with ProcessPoolExecutor(max_workers=CPU_COUNT) as executor:
        for chunk_number, (daily_chunk, monthly_chunk, yearly_chunk) in enumerate(executor.map(process_chunk, chunks)):
            for day, count in daily_chunk.items():
                daily_freq[day] = daily_freq.get(day, 0) + count
            for month, count in monthly_chunk.items():
                monthly_freq[month] = monthly_freq.get(month, 0) + count
            for year, count in yearly_chunk.items():
                yearly_freq[year] = yearly_freq.get(year, 0) + count
            
            if chunk_number % 10 == 0:
                print(f"Processed {CHUNK_SIZE * (chunk_number + 1):,} rows...")
    
    daily_series = pd.Series(daily_freq).sort_index()
    monthly_series = pd.Series(monthly_freq).sort_index()
    yearly_series = pd.Series(yearly_freq).sort_index()

    plot_and_save(daily_series, "Day-of-Month Transaction Frequency", "daily_transactions.png", list(range(1, 32)), "Day of Month")
    plot_and_save(monthly_series, "Monthly Transaction Frequency", "monthly_transactions.png", ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], "Month")
    plot_and_save(yearly_series, "Yearly Transaction Frequency", "yearly_transactions.png", yearly_series.index, "Year")
