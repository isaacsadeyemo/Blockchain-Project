import pandas as pd
import os
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from itertools import islice

CHUNK_SIZE = 100000
CPU_COUNT = os.cpu_count()

def process_chunk(chunk):
    return chunk['tx_gas_spent'].tolist()

def plot_line_graph(data, avg, median, min_val, max_val, filename):
    plt.figure(figsize=(12, 6))

    y, binEdges = np.histogram(data, bins=100)
    bincenters = 0.5 * (binEdges[1:] + binEdges[:-1])
    plt.plot(bincenters, y, '-', color='blue', label='Transaction Frequency')

    plt.axvline(avg, color='r', linestyle='dashed', linewidth=1, label=f"Average: {avg:.2f}")
    plt.axvline(median, color='g', linestyle='dashed', linewidth=1, label=f"Median: {median}")
    plt.axvline(min_val, color='c', linestyle='dotted', linewidth=1, label=f"Minimum: {min_val}")
    plt.axvline(max_val, color='m', linestyle='dotted', linewidth=1, label=f"Maximum: {max_val}")

    plt.title('Gas Spent per Transaction')
    plt.xlabel('Gas Spent')
    plt.ylabel('Number of Transactions')
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()

def split_dataframe(df, chunk_size=CHUNK_SIZE): 
    num_chunks = len(df) // chunk_size + 1
    return (df[i*chunk_size:(i+1)*chunk_size] for i in range(num_chunks))

if __name__ == '__main__':
    print("Starting the program...")

    df = pd.read_csv(r"C:\Users\Georgino\Desktop\FNCE-559-Project-2\group4.csv")

    df = df.drop_duplicates(subset='tx_hash', keep='first')

    chunks = split_dataframe(df, CHUNK_SIZE)

    all_gas_spent = []

    with ProcessPoolExecutor(max_workers=CPU_COUNT) as executor:
        for chunk_number, gas_spent_chunk in enumerate(executor.map(process_chunk, chunks)):
            all_gas_spent.extend(gas_spent_chunk)
            
            if chunk_number % 10 == 0:
                print(f"Processed {chunk_number * CHUNK_SIZE:,} rows...")

    avg_gas_spent = sum(all_gas_spent) / len(all_gas_spent)
    median_gas_spent = sorted(all_gas_spent)[len(all_gas_spent) // 2]
    min_gas_spent = min(all_gas_spent)
    max_gas_spent = max(all_gas_spent)

    print(f"\nAverage gas spent: {avg_gas_spent}")
    print(f"Median gas spent: {median_gas_spent}")
    print(f"Minimum gas spent: {min_gas_spent}")
    print(f"Maximum gas spent: {max_gas_spent}")

    plot_line_graph(all_gas_spent, avg_gas_spent, median_gas_spent, min_gas_spent, max_gas_spent, 'combined_gas_stats.png')

    print("Visualizations saved!")
