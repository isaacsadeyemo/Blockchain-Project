import pandas as pd
import os
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor
from itertools import islice

CHUNK_SIZE = 100000
CPU_COUNT = os.cpu_count()

def process_chunk(chunk):
    unique_senders = chunk['tx_sender'].unique()
    unique_recipients = chunk['tx_recipient'].unique()
    return unique_senders, unique_recipients

def plot_and_save(unique_senders_count, unique_recipients_count):
    labels = ['Unique Senders', 'Unique Recipients']
    values = [unique_senders_count, unique_recipients_count]

    plt.figure(figsize=(10, 6))
    bars = plt.bar(labels, values, color=['blue', 'green'])

    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, yval + 5000, round(yval, 2), ha='center', va='bottom', fontsize=10)

    plt.yscale('log')
    plt.ylabel('Count (Log Scale)')
    plt.title('Comparison of Unique Senders and Recipients')
    plt.tight_layout()

    plt.savefig('unique_senders_recipients_comparison.png', dpi=300)

def split_dataframe(df, chunk_size=CHUNK_SIZE): 
    num_chunks = len(df) // chunk_size + 1
    return (df[i*chunk_size:(i+1)*chunk_size] for i in range(num_chunks))

if __name__ == '__main__':
    print("Starting the program...")

    df = pd.read_csv(r"C:\Users\Georgino\Desktop\FNCE-559-Project-2\group4.csv")

    df = df.drop_duplicates(subset='tx_hash', keep='first')

    chunks = split_dataframe(df, CHUNK_SIZE)

    all_unique_senders = set()
    all_unique_recipients = set()

    with ProcessPoolExecutor(max_workers=CPU_COUNT) as executor:
        for chunk_number, (unique_senders_chunk, unique_recipients_chunk) in enumerate(executor.map(process_chunk, chunks)):
            all_unique_senders.update(unique_senders_chunk)
            all_unique_recipients.update(unique_recipients_chunk)
            
            if chunk_number % 10 == 0:
                print(f"Processed {chunk_number * CHUNK_SIZE:,} rows...")

    print(f"\nTotal unique senders: {len(all_unique_senders)}")
    print(f"Total unique recipients: {len(all_unique_recipients)}")

    # Plotting and saving the visualization
    plot_and_save(len(all_unique_senders), len(all_unique_recipients))
    print("Visualizations saved!")
